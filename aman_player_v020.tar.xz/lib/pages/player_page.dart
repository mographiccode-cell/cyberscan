import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:path_provider/path_provider.dart';
import 'package:screen_brightness/screen_brightness.dart';

import '../services/preferences_service.dart';

class PlayerPage extends StatefulWidget {
  const PlayerPage({
    super.key,
    required this.file,
    required this.title,
    required this.videoId,
    this.initialPosition = Duration.zero,
  });

  final File file;
  final String title;
  final String videoId;
  final Duration initialPosition;

  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  final _prefs = PreferencesService();
  late final Player _player;
  late final VideoController _controller;

  StreamSubscription<Duration>? _positionSub;
  StreamSubscription<bool>? _completedSub;
  Timer? _hideTimer;

  bool _locked = false;
  bool _controlsVisible = true;
  bool _repeat = false;
  bool _resumed = false;
  double _zoom = 1;
  double _startZoom = 1;
  double _subtitleSize = 22;
  BoxFit _fit = BoxFit.contain;
  Duration? _dragPreview;
  Duration _lastSavedPosition = Duration.zero;
  Duration _duration = Duration.zero;
  double? _startBrightness;
  double? _startVolume;

  @override
  void initState() {
    super.initState();
    _player = Player();
    _controller = VideoController(
      _player,
      configuration: const VideoControllerConfiguration(
        enableHardwareAcceleration: true,
      ),
    );
    _open();
  }

  Future<void> _open() async {
    await _player.open(
      Media(Uri.file(widget.file.path).toString()),
      play: false,
    );
    _duration = _player.state.duration;
    if (widget.initialPosition >= const Duration(seconds: 5)) {
      final duration = _player.state.duration;
      if (duration <= Duration.zero || widget.initialPosition < duration) {
        await _player.seek(widget.initialPosition);
        _lastSavedPosition = widget.initialPosition;
        _resumed = true;
      }
    }
    await _player.play();

    _positionSub = _player.stream.position.listen((position) {
      final duration = _player.state.duration;
      if (duration > Duration.zero) _duration = duration;
      if ((position - _lastSavedPosition).abs() >= const Duration(seconds: 3)) {
        _lastSavedPosition = position;
        _prefs.saveProgress(widget.videoId, position, _player.state.duration);
      }
    });
    _completedSub = _player.stream.completed.listen((completed) {
      if (completed && !_repeat) {
        _prefs.clearProgress(widget.videoId);
      }
    });

    if (mounted) {
      setState(() {});
      _scheduleControlsHide();
    }
  }

  @override
  void dispose() {
    _hideTimer?.cancel();
    _positionSub?.cancel();
    _completedSub?.cancel();
    _prefs.saveProgress(widget.videoId, _player.state.position, _player.state.duration);
    ScreenBrightness.instance.resetApplicationScreenBrightness();
    _player.dispose();
    super.dispose();
  }

  void _scheduleControlsHide() {
    _hideTimer?.cancel();
    if (_locked || !_controlsVisible) return;
    _hideTimer = Timer(const Duration(seconds: 4), () {
      if (mounted && !_locked) setState(() => _controlsVisible = false);
    });
  }

  void _showControls() {
    if (_locked) return;
    setState(() => _controlsVisible = true);
    _scheduleControlsHide();
  }

  String _fmt(Duration value) {
    final h = value.inHours;
    final m = value.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = value.inSeconds.remainder(60).toString().padLeft(2, '0');
    return h > 0 ? '$h:$m:$s' : '$m:$s';
  }

  Future<void> _saveScreenshot() async {
    final Uint8List? bytes = await _player.screenshot(
      format: 'image/jpeg',
      includeLibassSubtitles: true,
    );
    if (bytes == null || !mounted) return;
    final dir = await getTemporaryDirectory();
    final file = File(
      '${dir.path}${Platform.pathSeparator}aman_${DateTime.now().millisecondsSinceEpoch}.jpg',
    );
    await file.writeAsBytes(bytes, flush: true);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم التقاط صورة من الفيديو.')),
    );
  }

  Future<void> _showSpeedSheet() async {
    final current = _player.state.rate;
    final rate = await showModalBottomSheet<double>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 4, 18, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'سرعة التشغيل',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
              ),
              const SizedBox(height: 14),
              Wrap(
                spacing: 9,
                runSpacing: 9,
                children: [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0, 2.5, 3.0]
                    .map(
                      (value) => ChoiceChip(
                        label: Text('${value}x'),
                        selected: (current - value).abs() < 0.01,
                        onSelected: (_) => Navigator.pop(context, value),
                      ),
                    )
                    .toList(),
              ),
            ],
          ),
        ),
      ),
    );
    if (rate != null) {
      await _player.setRate(rate);
      _showControls();
    }
  }

  Future<void> _showTracksSheet() async {
    final audio = _player.state.tracks.audio;
    final subtitles = _player.state.tracks.subtitle;
    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.only(bottom: 20),
          children: [
            const ListTile(
              title: Text(
                'الصوت والترجمة',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
              ),
            ),
            const ListTile(
              title: Text('المسارات الصوتية', style: TextStyle(fontWeight: FontWeight.w800)),
            ),
            if (audio.isEmpty)
              const ListTile(
                leading: Icon(Icons.graphic_eq_rounded),
                title: Text('لا توجد مسارات صوتية إضافية'),
              ),
            ...audio.map(
              (track) => ListTile(
                leading: const Icon(Icons.graphic_eq_rounded),
                title: Text(track.title ?? track.language ?? 'مسار صوتي'),
                subtitle: Text(track.codec ?? ''),
                onTap: () async {
                  await _player.setAudioTrack(track);
                  if (context.mounted) Navigator.pop(context);
                },
              ),
            ),
            const Divider(),
            const ListTile(
              title: Text('الترجمة المدمجة', style: TextStyle(fontWeight: FontWeight.w800)),
            ),
            ListTile(
              leading: const Icon(Icons.subtitles_off_outlined),
              title: const Text('إيقاف الترجمة'),
              onTap: () async {
                await _player.setSubtitleTrack(SubtitleTrack.no());
                if (context.mounted) Navigator.pop(context);
              },
            ),
            if (subtitles.isEmpty)
              const ListTile(
                leading: Icon(Icons.subtitles_outlined),
                title: Text('لا توجد ترجمة مدمجة في هذا الفيديو'),
              ),
            ...subtitles.map(
              (track) => ListTile(
                leading: const Icon(Icons.subtitles_outlined),
                title: Text(track.title ?? track.language ?? 'ترجمة'),
                subtitle: Text(track.codec ?? ''),
                onTap: () async {
                  await _player.setSubtitleTrack(track);
                  if (context.mounted) Navigator.pop(context);
                },
              ),
            ),
          ],
        ),
      ),
    );
    _showControls();
  }

  Future<void> _showSubtitleStyleSheet() async {
    final value = await showModalBottomSheet<double>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 6, 18, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('حجم الترجمة', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
              const SizedBox(height: 10),
              Wrap(
                spacing: 10,
                children: [18.0, 22.0, 26.0, 30.0, 34.0]
                    .map(
                      (size) => ChoiceChip(
                        label: Text('${size.toInt()}'),
                        selected: _subtitleSize == size,
                        onSelected: (_) => Navigator.pop(context, size),
                      ),
                    )
                    .toList(),
              ),
            ],
          ),
        ),
      ),
    );
    if (value != null && mounted) setState(() => _subtitleSize = value);
    _showControls();
  }

  Future<void> _seekBy(Duration delta) async {
    final duration = _player.state.duration;
    var target = _player.state.position + delta;
    if (target < Duration.zero) target = Duration.zero;
    if (duration > Duration.zero && target > duration) target = duration;
    await _player.seek(target);
    _showControls();
  }

  Future<void> _toggleRepeat() async {
    _repeat = !_repeat;
    await _player.setPlaylistMode(_repeat ? PlaylistMode.single : PlaylistMode.none);
    if (mounted) setState(() {});
    _showControls();
  }

  void _cycleFit() {
    setState(() {
      _fit = switch (_fit) {
        BoxFit.contain => BoxFit.cover,
        BoxFit.cover => BoxFit.fitWidth,
        _ => BoxFit.contain,
      };
    });
    _showControls();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      onPopInvokedWithResult: (_, __) {
        _prefs.saveProgress(widget.videoId, _player.state.position, _player.state.duration);
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              return GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () {
                  if (_locked) return;
                  setState(() => _controlsVisible = !_controlsVisible);
                  _scheduleControlsHide();
                },
                onDoubleTapDown: (details) {
                  if (_locked) return;
                  final left = details.localPosition.dx < constraints.maxWidth / 2;
                  _seekBy(Duration(seconds: left ? -10 : 10));
                },
                onScaleStart: (_) {
                  if (_locked) return;
                  _startZoom = _zoom;
                },
                onScaleUpdate: (details) {
                  if (_locked || details.pointerCount < 2) return;
                  setState(() => _zoom = (_startZoom * details.scale).clamp(0.8, 3.0).toDouble());
                },
                onHorizontalDragStart: (_) {
                  if (_locked) return;
                  _dragPreview = _player.state.position;
                  _hideTimer?.cancel();
                },
                onHorizontalDragUpdate: (details) {
                  if (_locked || _dragPreview == null) return;
                  final duration = _player.state.duration;
                  if (duration <= Duration.zero) return;
                  final deltaMs = (details.delta.dx / constraints.maxWidth * 90000).round();
                  var next = _dragPreview! + Duration(milliseconds: deltaMs);
                  if (next < Duration.zero) next = Duration.zero;
                  if (next > duration) next = duration;
                  setState(() => _dragPreview = next);
                },
                onHorizontalDragEnd: (_) async {
                  if (_locked || _dragPreview == null) return;
                  final target = _dragPreview!;
                  setState(() => _dragPreview = null);
                  await _player.seek(target);
                  _showControls();
                },
                onVerticalDragStart: (details) async {
                  if (_locked) return;
                  if (details.localPosition.dx < constraints.maxWidth / 2) {
                    _startBrightness = await ScreenBrightness.instance.application;
                  } else {
                    _startVolume = _player.state.volume;
                  }
                },
                onVerticalDragUpdate: (details) async {
                  if (_locked) return;
                  final delta = -details.delta.dy / constraints.maxHeight;
                  if (details.localPosition.dx < constraints.maxWidth / 2) {
                    final start = _startBrightness ?? await ScreenBrightness.instance.application;
                    final next = (start + delta).clamp(0.02, 1.0).toDouble();
                    _startBrightness = next;
                    await ScreenBrightness.instance.setApplicationScreenBrightness(next);
                  } else {
                    final start = _startVolume ?? _player.state.volume;
                    final next = (start + delta * 100).clamp(0.0, 100.0).toDouble();
                    _startVolume = next;
                    await _player.setVolume(next);
                  }
                },
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Center(
                      child: Transform.scale(
                        scale: _zoom,
                        child: Video(
                          controller: _controller,
                          fit: _fit,
                          controls: NoVideoControls,
                          subtitleViewConfiguration: SubtitleViewConfiguration(
                            style: TextStyle(
                              fontSize: _subtitleSize,
                              height: 1.35,
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                              backgroundColor: Colors.black.withValues(alpha: 0.28),
                              shadows: const [Shadow(color: Colors.black, blurRadius: 5)],
                            ),
                            textAlign: TextAlign.center,
                            padding: const EdgeInsets.fromLTRB(24, 24, 24, 48),
                          ),
                        ),
                      ),
                    ),
                    if (_resumed)
                      Positioned(
                        top: 58,
                        left: 18,
                        right: 18,
                        child: IgnorePointer(
                          child: Center(
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                              decoration: BoxDecoration(
                                color: Colors.black.withValues(alpha: 0.68),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                'تم الاستئناف من ${_fmt(widget.initialPosition)}',
                                style: const TextStyle(color: Colors.white),
                              ),
                            ),
                          ),
                        ),
                      ),
                    if (_dragPreview != null)
                      Center(
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: 0.78),
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                            child: Text(
                              _fmt(_dragPreview!),
                              style: const TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ),
                    if (_controlsVisible || _locked) _buildControls(context),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildControls(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        IgnorePointer(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withValues(alpha: 0.76),
                  Colors.transparent,
                  Colors.black.withValues(alpha: 0.84),
                ],
                stops: const [0, 0.48, 1],
              ),
            ),
          ),
        ),
        Align(
          alignment: Alignment.topCenter,
          child: Row(
            children: [
              IconButton(
                color: Colors.white,
                icon: const Icon(Icons.arrow_back_rounded),
                onPressed: () => Navigator.pop(context),
              ),
              Expanded(
                child: Text(
                  widget.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
              ),
              if (!_locked) ...[
                IconButton(
                  tooltip: 'تكرار الفيديو',
                  color: _repeat ? Theme.of(context).colorScheme.primary : Colors.white,
                  onPressed: _toggleRepeat,
                  icon: const Icon(Icons.repeat_one_rounded),
                ),
                PopupMenuButton<String>(
                  color: Theme.of(context).colorScheme.surface,
                  iconColor: Colors.white,
                  onSelected: (value) {
                    if (value == 'tracks') _showTracksSheet();
                    if (value == 'speed') _showSpeedSheet();
                    if (value == 'subtitle_style') _showSubtitleStyleSheet();
                    if (value == 'screenshot') _saveScreenshot();
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'speed', child: Text('سرعة التشغيل')),
                    PopupMenuItem(value: 'tracks', child: Text('الصوت والترجمة')),
                    PopupMenuItem(value: 'subtitle_style', child: Text('حجم الترجمة')),
                    PopupMenuItem(value: 'screenshot', child: Text('التقاط صورة')),
                  ],
                ),
              ],
            ],
          ),
        ),
        Center(
          child: _locked
              ? IconButton.filledTonal(
                  onPressed: () {
                    setState(() => _locked = false);
                    _showControls();
                  },
                  icon: const Icon(Icons.lock_rounded),
                )
              : StreamBuilder<bool>(
                  stream: _player.stream.playing,
                  initialData: _player.state.playing,
                  builder: (context, snapshot) {
                    final playing = snapshot.data ?? false;
                    return Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        IconButton(
                          color: Colors.white,
                          iconSize: 34,
                          onPressed: () => _seekBy(const Duration(seconds: -10)),
                          icon: const Icon(Icons.replay_10_rounded),
                        ),
                        const SizedBox(width: 18),
                        IconButton.filled(
                          iconSize: 44,
                          onPressed: () {
                            _player.playOrPause();
                            _showControls();
                          },
                          icon: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded),
                        ),
                        const SizedBox(width: 18),
                        IconButton(
                          color: Colors.white,
                          iconSize: 34,
                          onPressed: () => _seekBy(const Duration(seconds: 10)),
                          icon: const Icon(Icons.forward_10_rounded),
                        ),
                      ],
                    );
                  },
                ),
        ),
        if (!_locked)
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(14, 8, 14, 8),
              child: StreamBuilder<Duration>(
                stream: _player.stream.position,
                initialData: _player.state.position,
                builder: (context, posSnapshot) {
                  return StreamBuilder<Duration>(
                    stream: _player.stream.duration,
                    initialData: _player.state.duration,
                    builder: (context, durSnapshot) {
                      final position = posSnapshot.data ?? Duration.zero;
                      final duration = durSnapshot.data ?? _duration;
                      final maxMs = duration.inMilliseconds > 0 ? duration.inMilliseconds.toDouble() : 1.0;
                      final value = position.inMilliseconds.clamp(0, maxMs.toInt()).toDouble();
                      return Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Slider(
                            value: value,
                            max: maxMs,
                            onChanged: (v) {
                              _player.seek(Duration(milliseconds: v.round()));
                              _showControls();
                            },
                          ),
                          Row(
                            children: [
                              Text(_fmt(position), style: const TextStyle(color: Colors.white)),
                              const Text(' / ', style: TextStyle(color: Colors.white70)),
                              Text(_fmt(duration), style: const TextStyle(color: Colors.white70)),
                              const Spacer(),
                              StreamBuilder<double>(
                                stream: _player.stream.rate,
                                initialData: _player.state.rate,
                                builder: (context, rateSnapshot) {
                                  final rate = rateSnapshot.data ?? 1.0;
                                  return TextButton(
                                    onPressed: _showSpeedSheet,
                                    child: Text('${rate.toStringAsFixed(rate == rate.roundToDouble() ? 0 : 2)}x', style: const TextStyle(color: Colors.white)),
                                  );
                                },
                              ),
                              IconButton(
                                tooltip: 'طريقة ملء الشاشة',
                                color: Colors.white,
                                onPressed: _cycleFit,
                                icon: const Icon(Icons.aspect_ratio_rounded),
                              ),
                              IconButton(
                                tooltip: 'قفل الشاشة',
                                color: Colors.white,
                                onPressed: () => setState(() => _locked = true),
                                icon: const Icon(Icons.lock_open_rounded),
                              ),
                            ],
                          ),
                          const Text(
                            'نقر مزدوج: ±10 ثوانٍ • سحب أفقي: تقديم/ترجيع • يسار: سطوع • يمين: صوت • قرص بإصبعين: تكبير',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.white54, fontSize: 10),
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
            ),
          ),
      ],
    );
  }
}
